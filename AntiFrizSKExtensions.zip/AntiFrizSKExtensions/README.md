# AntiFriz_HSK_Extensions

This mod add a lot of muskets and other things for [HSK](https://github.com/skyarkhangel/Hardcore-SK), almost overhaul for midleages firearm... and some further.

Also planed weapons from warhammer 40k (yeah), and some exotic modern firearms (hello, ForgottenWeapons fans! :) ).

Balanse is off, working on it.
